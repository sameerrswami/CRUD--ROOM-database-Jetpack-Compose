package com.example.aclass.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.aclass.data.AppDatabase
import com.example.aclass.data.ItemEntity
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class ItemViewModel(application: Application) : AndroidViewModel(application) {
    private val dao = AppDatabase.getDatabase(application).itemDao()

    val items: StateFlow<List<ItemEntity>> = dao.getAllItems()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    fun addItem(name: String, description: String) {
        if (name.isBlank()) return
        viewModelScope.launch {
            dao.insertItem(ItemEntity(name = name, description = description))
        }
    }

    fun updateItem(item: ItemEntity, newName: String, newDescription: String) {
        if (newName.isBlank()) return
        viewModelScope.launch {
            dao.updateItem(item.copy(name = newName, description = newDescription))
        }
    }

    fun deleteItem(item: ItemEntity) {
        viewModelScope.launch {
            dao.deleteItem(item)
        }
    }
}
